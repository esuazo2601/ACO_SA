#include <vector>
#include <string>

int hamming_cuadrado(std::string sol_in, std::vector<std::string>entrada);
char pick_random_letter();
std::vector<std::string> lee_instancia(std::string nombre);